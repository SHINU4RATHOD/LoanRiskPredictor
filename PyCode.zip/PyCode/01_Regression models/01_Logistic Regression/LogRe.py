import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.impute import SimpleImputer
from feature_engine.outliers import Winsorizer
from sklearn.preprocessing import MinMaxScaler, StandardScaler, OneHotEncoder, PolynomialFeatures
from sklearn.pipeline import Pipeline, make_pipeline
from sklearn.compose import ColumnTransformer

from sklearn.model_selection import train_test_split, cross_val_score, KFold, GridSearchCV, RandomizedSearchCV

# model
from sklearn.linear_model import LogisticRegression

# evaluation
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, roc_auc_score
 
from sqlalchemy import create_engine
import joblib
import pickle
# loading dataset
df = pd.read_json(r'C:/Users/SHINU RATHOD/Desktop/internship assignment/Recsify Technologies/03_dataset/Dataset/loan_approval_dataset.json') 
# df.to_csv(r'C:/Users/SHINU RATHOD/Desktop/internship assignment/Recsify Technologies/03_dataset/Dataset/loan_approval_dataset.csv', index=False)
#pushing dataset to mysql database
engine = create_engine("mysql+pymysql://{user}:{pw}@localhost/{db}".format(user = 'root', pw = '1122', db='project'))
# df.to_sql('la', con = engine, if_exists = 'replace', chunksize = 1000, index = False)
sql = 'select * from la;'
df = pd.read_sql_query(sql, engine)
df.head()


df = df.drop(columns = ['Id','Married/Single', 'CITY', 'STATE'], axis = 1)

df.info()
df.describe()
df.isnull().sum()

################# Extracting the independent and dependent var
x = df.drop('Risk_Flag', axis = 1)
y = df['Risk_Flag']   

nf = x.select_dtypes(exclude = 'object').columns
cf = x.select_dtypes(include = 'object').columns

########################## creating the pipline for simpleImputer
num_pipeline = Pipeline(steps = [('impute', SimpleImputer(strategy = 'mean'))])
preprocessor = ColumnTransformer(transformers = [('num', num_pipeline, nf)])

imputation = preprocessor.fit(x)
joblib.dump(imputation, 'meanimpute')

imputed_df = pd.DataFrame(imputation.transform(x), columns = nf)
imputed_df.isnull().sum()


# plotting the box plot for to check outliers
imputed_df.plot(kind = 'box', subplots = True, sharey = False, figsize = (15, 8)) 
plt.subplots_adjust(wspace = 0.75) 
plt.show()      #after plotting box plot seems there in no outliers present in dataset
################### Create a preprocessing pipeline for Winsorization(for to handle outliers if it face new extreme data value)
winsorizer_pipeline = Winsorizer(capping_method = 'iqr', tail = 'both', fold = 1.5)
X_winsorized = winsorizer_pipeline.fit(imputed_df)
joblib.dump(X_winsorized, 'winsor')

X_winsorized_df = pd.DataFrame(X_winsorized.transform(imputed_df), columns = nf)
#plotting box plot after winsorisizing
X_winsorized_df.plot(kind = 'box', subplots = True, sharey = False, figsize = (15, 8)) 
plt.subplots_adjust(wspace = 0.75)  
plt.show()


############################ creating pipline for MinmaxScaler(features scaling)
scale_pipeline = Pipeline([('scale', MinMaxScaler())])
X_scaled = scale_pipeline.fit(X_winsorized_df)
joblib.dump(X_scaled, 'minmax')

X_scaled_df = pd.DataFrame(X_scaled.transform(X_winsorized_df), columns = nf)


############################ creating pipline for OneHotEncoder
encoding_pipeline = Pipeline([('onehot', OneHotEncoder(drop='first'))])

preprocess_pipeline = ColumnTransformer([('cat', encoding_pipeline, cf)])
X_encoded =  preprocess_pipeline.fit(x)   # Works with categorical features only
# Save the encoding model
joblib.dump(X_encoded, 'encoding')

encode_data = pd.DataFrame(X_encoded.transform(x).todense())
# To get feature names for Categorical columns after Onehotencoding 
encode_data.columns = X_encoded.get_feature_names_out(input_features = x.columns)
encode_data.info()

clean_data = pd.concat([X_scaled_df, encode_data], axis = 1)  # concatenated data will have new sequential index
clean_data.info()

#################### model building Statsmodel
import statsmodels.api as sm
from sklearn import metrics
from sklearn.metrics import r2_score, confusion_matrix, accuracy_score, classification_report, roc_auc_score, roc_curve
logit_model = sm.Logit(y, clean_data).fit()
pickle.dump(logit_model, open('logistic.pkl', 'wb'))
# Summary
logit_model.summary()
logit_model.summary2() # for AIC (It is a statistical measure used in model selection and model comparison)

# Prediction
pred = logit_model.predict(clean_data)
 
# ROC Curve to identify the appropriate cutoff value
fpr, tpr, thresholds = roc_curve(y, pred)
optimal_idx = np.argmax(tpr - fpr)  # tpr and fpr diff should be max
optimal_threshold = thresholds[optimal_idx]
optimal_threshold


auc = metrics.auc(fpr, tpr)
print("Area under the ROC curve : %f" % auc)
# Filling all the cells with zeroes
clean_data["pred"] = np.zeros(252000)
# taking threshold value and above the prob value will be treated as correct value 
clean_data.loc[pred > optimal_threshold, "pred"] = 1

# Confusion Matrix
confusion_matrix(clean_data.pred, y)

# Accuracy score of the model
print('Test accuracy = ', accuracy_score(clean_data.pred, y))

# Classification report
classification = classification_report(clean_data.pred, y)
print(classification)

### PLOT FOR ROC
plt.plot(fpr, tpr, label = "AUC="+str(auc))
plt.ylabel('True Positive Rate')
plt.xlabel('False Positive Rate')
plt.legend(loc = 4)
plt.show()


################################################################
# Model evaluation - Data Split
x_train, x_test, y_train, y_test = train_test_split(clean_data.drop(columns=['pred']), y, test_size=0.2, random_state=0, stratify=y)
logisticmodel = sm.Logit(y_train, x_train).fit()

# Evaluate on train data
y_pred_train = logisticmodel.predict(x_train)

# Filling all the cells with zeroes
y_train_pred = np.zeros(len(y_train))
y_train_pred[y_pred_train > optimal_threshold] = 1

auc_train = metrics.roc_auc_score(y_train, y_pred_train)
print("Area under the ROC curve for train: %f" % auc_train)

classification_train = classification_report(y_train, y_train_pred)
print('Train accuracy = ', accuracy_score(y_train, y_train_pred))
print(classification_train)
print(confusion_matrix(y_train, y_train_pred))


# Validate on Test data
y_pred_test = logisticmodel.predict(x_test)

# Filling all the cells with zeroes
y_test_pred = np.zeros(len(y_test))
y_test_pred[y_pred_test > optimal_threshold] = 1

auc_test = metrics.roc_auc_score(y_test, y_pred_test)
print("Area under the ROC curve for test: %f" % auc_test)

classification_test = classification_report(y_test, y_test_pred)
print('Test accuracy = ', accuracy_score(y_test, y_test_pred))
print(classification_test)
print(confusion_matrix(y_test, y_test_pred))


 




#############################################
# Test the best model on new data
model1 = pickle.load(open('logistic.pkl', 'rb'))
impute = joblib.load('meanimpute')
winzor = joblib.load('winsor')
minmax = joblib.load('minmax')
encode = joblib.load('encoding')
# Load the new data
data = pd.read_excel(r"C:/Users/SHINU RATHOD/Desktop/internship assignment/Recsify Technologies/03_dataset/Dataset/loan_approval_test_dataset.xlsx")
data = data.drop(columns = ['Id','Married/Single', 'CITY', 'STATE'], axis = 1)
data.info()
data.head()
  
#extracting numerical and categorical columns
nf = data.select_dtypes(exclude = 'object').columns
cf = data.select_dtypes(include = 'object').columns

# Engine = create_engine(f"mysql+pymysql://{user}:{pw}@localhost/{db}") #database
clean = pd.DataFrame(impute.transform(data), columns = nf)

clean1 = pd.DataFrame(winzor.transform(clean), columns = clean.columns)

clean2 = pd.DataFrame(minmax.transform(clean1), columns = clean1.columns)

clean3 = pd.DataFrame(encode.transform(data), columns = encode.get_feature_names_out())
prediction = model1.predict(clean3)
prediction

# optimal_threshold=0.60
data["ATTORNEY"] = np.zeros(len(prediction))

# taking threshold value and above the prob value will be treated as correct value 
data.loc[prediction > optimal_threshold, "ATTORNEY"] = 1
data[['ATTORNEY']] = data[['ATTORNEY']].astype('int64')






####################### model testing on new data
model1 = pickle.load(open('logistic.pkl', 'rb'))
impute = joblib.load('meanimpute')
winzor = joblib.load('winsor')
minmax = joblib.load('minmax')
encode = joblib.load('encoding')
data = pd.read_excel(r"C:/Users/SHINU RATHOD/Desktop/internship assignment/Recsify Technologies/03_dataset/Dataset/loan_approval_test_dataset.xlsx")
data = data.drop(columns = ['Id','Married/Single', 'CITY', 'STATE'], axis = 1)

nf = data.select_dtypes(exclude='object').columns
cf = data.select_dtypes(include = 'object').columns

x_impute = pd.DataFrame(impute.transform(data), columns = nf)
x_winz = pd.DataFrame(winzor.transform(x_impute), columns = x_impute.columns)
x_scale = pd.DataFrame(minmax.transform(x_winz), columns = x_winz.columns)

x_encode = pd.DataFrame(encode.transform(data), columns = encode.get_feature_names_out())
clean = pd.concat([x_scale, x_encode], axis=1)
prediction = pd.DataFrame(model1.predict(clean), columns = ['machin_failure_pred'])
prediction
final = pd.concat([prediction, data], axis = 1)
final['machin_failure_pred'].value_counts()
